import UIKit

// MARK: -Reverse String
func reverseFirstAndThirdChar(_ str: String) -> String {
    var reversedString = ""
    var reversedCharString = ""
    for char in str {
        if char.isWhitespace {
            reversedString += reversedChar(str: reversedCharString) + " "
            reversedCharString = ""
        }
         else {
             reversedCharString.append(char)
        }
        
    }
    if !reversedCharString.isEmpty {
        reversedString += reversedChar(str: reversedCharString)
        }
    
    return reversedString.trimmingCharacters(in: .whitespaces)
    
}


func reversedChar(str: String) -> String {
    var chars = Array(str)
       let count = chars.count
       
       if count > 2 {
           // Swap the first and third characters
           let temp = chars[0]
           chars[0] = chars[2]
           chars[2] = temp
       }
       
       return String(chars)
}

// Example usage
let inputString = "tic tac toe"
let modifiedString = reverseFirstAndThirdChar(inputString)
print(modifiedString)  // Output: "cit tac toe"



func reverseString() {
    var string = "cat dog hen monkey"
    var reversedChar = [Character]()
    var reversedString = ""
    for char in string {
        reversedChar.append(char)
    }
    
    print(reversedChar)
    var count = reversedChar.count
    for i in 0..<count {
        print(i)
        var index = count-1-i
        print(reversedChar[index])
        reversedString += "\(reversedChar[count-1-i])"
    }
    
    print(reversedString)
}

reverseString()

